
-- 7.0.0   Introduction to Monitoring Usage and Billing
--         The purpose of this lab is to familiarize you with the Snowflake
--         database, the schemas in the database, how you can use this data to
--         monitor how users are using the objects in your system, and the costs
--         associated with that usage.
--         - Monitor usage and billing with the ACCOUNT_USAGE schema.
--         - Determine which virtual warehouses do not have resource monitors.
--         - Determine the most expensive queries from the last 30 days.
--         - Determine the top 10 queries with the most spillage to remote
--         storage.
--         HOW TO COMPLETE THIS LAB
--         Since the workbook PDF has useful diagrams and illustrations (not
--         present in the .SQL files), we recommend that you read the
--         instructions from the workbook PDF. In order to execute the code
--         presented in each step, use the SQL code file provided for this lab.
--         Snowflake Database
--         Snowflake provides a system-defined, read-only shared database named
--         SNOWFLAKE that contains metadata and historical usage data about the
--         objects in your organization and accounts.
--         The purpose of the database is to allow you to monitor object usage
--         metrics and the costs associated with that usage so you can make any
--         adjustments needed to get the most for the consumed credits.
--         There are many schemas in the SNOWFLAKE database, but the one we will
--         concentrate on is ACCOUNT_USAGE.
--         We have given you access to ACCOUNT_USAGE for learning purposes. By
--         default, however, only users with the ACCOUNTADMIN role can access
--         the SNOWFLAKE database and schemas or perform queries on the views.
--         Privileges on the database can be granted to other roles in your
--         account to allow other users to access the objects.
--         Links to more information about the SNOWFLAKE database and the
--         associated schemas can be found here:
--         Click here for Snowflake Database (https://docs.snowflake.com/en/sql-
--         reference/snowflake-db.html)
--         Let’s get started!

-- 7.1.0   Upload and Open the SQL File

-- 7.1.1   Go to the Workspaces page.
--         In the left navigation bar, hover over Projects, then select
--         Workspaces.

-- 7.1.2   Close all open tabs.
--         Click the gear icon in the top right of the Workspaces page and
--         select Close all tabs.

-- 7.1.3   Upload the SQL file for this lab into My Workspace.
--         In the My Workspace pane, click + Add new, then select Upload Files.
--         Then:
--         - Navigate to where you downloaded and unzipped the lab files.
--         - Open the USERS folder, and then open the sub-folder with your
--         username.
--         - Select and upload the SQL file for this lab.
--         Once the file has been uploaded, select the file in the My Workspace
--         pane. The file opens in a new Workspaces tab.

-- 7.2.0   Monitor Usage and Billing with the ACCOUNT_USAGE schema
--         The ACCOUNT_USAGE schema supports usage and billing monitoring
--         because it exposes a number of secure views that display data related
--         to object usage history, grants to roles and users, data loading
--         history, metering history, storage history, task history, users,
--         roles, and more.
--         The main approach to writing queries that will help you monitor usage
--         and billing is to look at the views that appear relevant and then run
--         through the column list to see if they relate to your goal. As there
--         are many views in each schema, some with many columns, it will take
--         time and experience working with the schemas to become sufficiently
--         familiar with them to get the answers you want.

-- 7.2.1   Set your context.
--         You will use SNOWFLAKE.ACCOUNT_USAGE as your database and schema for
--         this lab.

USE ROLE fund_role;

CREATE WAREHOUSE IF NOT EXISTS GROUNDHOG_fund_wh INITIALLY_SUSPENDED=TRUE;
USE WAREHOUSE GROUNDHOG_fund_wh;

USE SCHEMA snowflake.account_usage;


-- 7.2.2   Examine credit usage by virtual warehouse.
--         Monitoring credit consumption for specific objects is a classic use
--         of data in the ACCOUNT_USAGE schema. Here is an example of two
--         queries that use the WAREHOUSE_METERING_HISTORY view.

-- Credits used (all time = past year)

SELECT warehouse_name,
       SUM(credits_used_compute) AS credits_used_compute_sum
  FROM account_usage.warehouse_metering_history
 GROUP BY 1
 ORDER BY 2 DESC;

-- Credits used (past N days/weeks/months)

SELECT warehouse_name,
       SUM(credits_used_compute) AS credits_used_compute_sum
  FROM account_usage.warehouse_metering_history
 WHERE START_TIME >= DATEADD(DAY, -7, CURRENT_TIMESTAMP())  // Past 7 days
 GROUP BY 1
 ORDER BY 2 DESC;

--         Notice the GROUP BY 1 and ORDER BY 2 in the query above. If your
--         column names are long, you can group or order by the column position
--         rather than the column name.
--         These queries enable you to determine if there are specific virtual
--         warehouses that are consuming more credits than the others. You can
--         then drill into questions such as:
--         Should that virtual warehouse be consuming that quantity of credits?
--         Are specific virtual warehouses consuming more credits than
--         anticipated?
--         In the event a virtual warehouse is consuming too many credits, you
--         could take action to rectify the situation. Depending on what the
--         virtual warehouse is being used for, you could consider modifying the
--         auto-suspend policy or the scaling policy, checking the data loading
--         history to see if efficient practices are being used, analyzing the
--         size and efficiency of queries being run on the virtual warehouse, or
--         adding a resource monitor to the virtual warehouse.
--         Below is a list of columns in the WAREHOUSE_METERING_HISTORY view.
--         Since Snowflake is continually adding functionality, this could be
--         somewhat different from what you’ll see in the Snowsight User
--         Interface.

-- 7.2.3   Identifying virtual warehouses with no resource monitor.
--         If you have virtual warehouses that are using too many credits, you
--         can create a resource monitor to track the credits used.
--         The query below identifies all virtual warehouses without resource
--         monitors in place. Resource monitors provide the ability to set
--         limits on the credits consumed by a virtual warehouse during a
--         specific time interval or date range. This can help prevent specific
--         virtual warehouses from unintentionally consuming more credits than
--         expected.

SHOW WAREHOUSES;

SELECT "name" AS warehouse_name,
       "size" AS warehouse_size
  FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
 WHERE "resource_monitor" = 'null';

--         Ideally, there should be a resource monitor for all virtual
--         warehouses. By default, only ACCOUNTADMIN can create resource
--         monitors.

-- 7.3.0   Billing Metrics
--         Billing metrics are all about analyzing what you’ve been billed in
--         the past to determine if there is a way to lower your costs in the
--         future.

-- 7.3.1   Most expensive queries from the last 60 days.
--         The query below analyzes queries that are potentially too expensive
--         by ordering the most expensive ones from the last 60 days. It takes
--         into account the virtual warehouse size, assuming that a one-minute
--         query on a larger virtual warehouse is more expensive than a one-
--         minute query on a smaller virtual warehouse. The query only checks
--         for queries that ran on standard virtual warehouses and does not
--         differentiate between Gen1 and Gen2.

WITH warehouse_credits (warehouse_size, credits_per_hour)
AS (
  SELECT * FROM
    (VALUES
        ('X-SMALL', 1),
        ('SMALL', 2),
        ('MEDIUM', 4),
        ('LARGE', 8),
        ('X-LARGE', 16),
        ('2X-LARGE', 32),
        ('3X-LARGE', 64),
        ('4X-LARGE', 128),
        ('5X-LARGE', 256),
        ('6X-LARGE', 512)
    )
)
SELECT
  qh.query_id,
  qh.query_text,
  qh.user_name,
  qh.role_name,
  qh.execution_time,
  ROUND(qh.execution_time / 1000, 2) AS execution_seconds,
  ROUND(qh.execution_time / 60000, 2) AS execution_minutes,
  ROUND(qh.execution_time / 3600000, 2) AS execution_hours,
  qh.warehouse_name,
  qh.warehouse_type,
  qh.warehouse_size,
  wc.credits_per_hour,
  (qh.execution_time / 3600000) * wc.credits_per_hour AS credits_consumed
FROM
  snowflake.account_usage.query_history AS qh
  JOIN warehouse_credits AS wc ON UPPER(qh.warehouse_size) = wc.warehouse_size
WHERE
  warehouse_name IS NOT NULL
  AND warehouse_type = 'STANDARD'
  AND start_time > DATEADD (MONTH, -2, CURRENT_TIMESTAMP())
ORDER BY
  credits_consumed DESC
LIMIT
  200;

--         This query gives you the chance to evaluate expensive queries and
--         take some action. For example, you could look at the query profile,
--         contact the user who executed the query or take action to optimize
--         these queries.
--         Below is a partial list of the columns in this secure view,
--         SNOWFLAKE.ACCOUNT_USAGE.QUERY_HISTORY.

-- 7.3.2   Top 10 queries with the most spillage to remote storage.
--         Another way to evaluate the cost of queries is to see if they are
--         spilling to remote storage. The query below enables you to do that.

SELECT query_id, substr(query_text, 1, 50) partial_query_text, user_name, warehouse_name, warehouse_size, 
       bytes_spilled_to_remote_storage, start_time, end_time, total_elapsed_time/1000 total_elapsed_time
FROM   snowflake.account_usage.query_history
WHERE  bytes_spilled_to_remote_storage > 0
AND start_time::date > dateadd('days', -45, current_date)
ORDER BY bytes_spilled_to_remote_storage DESC
LIMIT 10;

--         Because you are in a training account, it is likely that you won’t
--         find any queries that have remote spillage. However, in a production
--         environment, you will most likely encounter queries that have some
--         remote spillage.
--         This query also provides the virtual warehouse name and size. Once
--         you identify the queries that are spilling to remote storage, you can
--         take action to ensure they are run on larger virtual warehouses with
--         more local storage and memory.

-- 7.4.0   Key Takeaways
--         - There are many views in each schema of the Snowflake database, some
--         with many columns. It will take time and experience working with the
--         schemas to become sufficiently familiar with them to get the answers
--         you need.
--         - Resource monitors provide the ability to set limits on credits
--         consumed by a virtual warehouse during a specific time interval or
--         date range.
--         - The Snowflake database enables you to determine where you have high
--         credit consumption so you can ask pertinent questions about why that
--         is occurring. You can use this information to help you consider steps
--         to bring down costs.
