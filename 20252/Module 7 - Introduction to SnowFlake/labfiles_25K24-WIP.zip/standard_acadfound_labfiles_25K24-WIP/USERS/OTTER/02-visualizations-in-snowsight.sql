
-- 2.0.0   Visualizations in Snowsight
--         The purpose of this lab is to show you how to use the visualization
--         features and tools available in Snowsight. Specifically, you’ll learn
--         how to leverage our built-in contextual statistics columns in order
--         to gain quick insights into data. Also, you’ll learn how to create a
--         dashboard from an existing query.
--         - Explore the use of ad hoc filters and visualization Workspaces.
--         - Create and share a dashboard with multiple tiles.
--         Snowbear Air is interested in seeing a year-by-year summary of gross
--         sales grouped by order priority. You’ve been asked to create and
--         share a Snowflake dashboard. You’ve decided to use the
--         PROMO_CATALOG_SALES schema to accomplish your task.
--         HOW TO COMPLETE THIS LAB
--         Since the workbook PDF has useful diagrams and illustrations (not
--         present in the .SQL files), we recommend that you read the
--         instructions from the workbook PDF. In order to execute the code
--         presented in each step, use the SQL code file provided for this lab.
--         Note that this lab contains many steps that involve navigating the
--         Snowsight UI. The best way to complete this exercise is to read the
--         instructions from the PDF workbook for the entire lab from start to
--         finish.
--         Let’s get started!

-- 2.1.0   Set Up for the Lab

-- 2.1.1   Go to the Workspaces page.
--         In the left navigation bar, hover over Projects, then select
--         Workspaces.

-- 2.1.2   Close all open tabs.
--         Click the gear icon in the top right of the Workspaces page and
--         select Close all tabs.

-- 2.1.3   Upload the SQL file for this lab into My Workspace.
--         In the My Workspace pane, click + Add new, then select Upload Files.
--         Then:
--         - Navigate to where you downloaded and unzipped the lab files.
--         - Open the USERS folder, and then open the sub-folder with your
--         username.
--         - Select and upload the file for this lab: 02-visualizations-in-
--         snowsight.sql.
--         Once the file has been uploaded, select the file in the My Workspace
--         pane. The file opens in a new Workspaces tab as shown in the graphic.

-- 2.1.4   Set your context.
--         Scroll down to the context commands shown below and execute them.

USE ROLE fund_role;
USE SCHEMA snowbearair_db.promo_catalog_sales;
CREATE WAREHOUSE IF NOT EXISTS OTTER_fund_wh;
USE WAREHOUSE OTTER_fund_wh;


-- 2.2.0   Run a Query and Analyze the Results

-- 2.2.1   Run the query to determine monthly revenue grouped by order priority.

SELECT 
  -- Truncate order date to month level for aggregation
  DATE_TRUNC('MONTH', o.o_orderdate) AS month,
  -- Calculate total revenue for the month
  SUM(l.l_extendedprice) AS sum_gross_revenue,
  -- Group by order priority level
  o.o_orderpriority AS order_priority,
  -- Count distinct orders to avoid duplicates from line items
  COUNT(DISTINCT o.o_orderkey) AS order_count
FROM
        customer c
        INNER JOIN orders o on c.c_custkey = o.o_custkey
        INNER JOIN lineitem l on o.o_orderkey = l.l_orderkey
GROUP BY month, o_orderpriority
ORDER BY month, o_orderpriority;


-- 2.2.2   In the Results tab click the Show column stats icon to see the column
--         statistics.
--         You should see the results below.

-- 2.2.3   Filter the results by ORDER_PRIORITY.
--         Filter the results to show the revenue for the URGENT and HIGH
--         priority orders.
--         Click anywhere in the ORDER_PRIORITY column statistics, a filter
--         dialog will pop-up. Select URGENT and HIGH and then click Apply.

-- 2.2.4   Filter the results by MONTH.
--         The filters in Workspaces are cumulative. The results now only show
--         the revenue filtered by the URGENT and HIGH priority orders. We can
--         filter the results further by limiting the data to a few months.
--         Click anywhere in the MONTH column statistics. The filter dialog
--         opens. Select a timeframe of your choice by clicking and dragging and
--         then click Apply.

-- 2.2.5   View the filtered results.
--         Here is an example of the results filtered by ORDER_PRIORITY and
--         MONTH.

-- 2.2.6   Clear all filters.
--         Clear out both the filters by clicking the X in each of the filters.

-- 2.2.7   Format the SUM_GROSS_REVENUE column.
--         You can change the formatting of columns with numbers to include or
--         exclude commas. Hover over the SUM_GROSS_REVENUE column name, and
--         click the three vertical dots that appear on the right side of the
--         column header. A formatting panel will appear. Click the picture of
--         the comma to add commas to the values in the column, as shown below:
--         You can click it again to remove the commas. You can also play with
--         the other options to see what they do. You should have commas but no
--         decimal values in the SUM_GROSS_REVENUE column when finished.

-- 2.3.0   Explore Visualizations in Workspaces
--         You should still be on the Workspaces page, with the monthly revenue
--         results displayed.

-- 2.3.1   Create a bar chart that shows gross revenue by year.
--         In the results tab click Chart.
--         Then use the following settings in the chart controls panel:
--         Chart type: Bar chart
--         X-Axis: MONTH
--         Time resolution: Year
--         Sort: None
--         Y-AXIS: SUM_GROSS_REVENUE
--         Aggregate: Sum
--         Group by: None
--         Title: Gross Revenue by Year
--         X-axis label: Year
--         Y-axis label: Gross Revenue
--         The resulting chart should look similar to the one shown below.

-- 2.3.2   Modify the chart to a stacked bar chart that shows the gross revenue
--         per year by order priority.
--         Change Chart type to Stacked bar chart.
--         Under Y-axis, set Group by to ORDER_PRIORITY.
--         Modify the title of the chart appropriately.
--         The resulting chart should look similar to the one shown below.

-- 2.3.3   Modify the chart to a pie chart that shows the order count
--         categorized by order priority.
--         Change Chart type to Pie chart.
--         Set Categories to ORDER_PRIORITY.
--         Set Values to ORDER_COUNT.
--         Set Aggregate to Sum.
--         Modify the title of the chart appropriately.
--         The resulting chart should look similar to the one shown below.
--         In the current release of Workspaces, charts and results cannot be
--         shared or displayed in dashboards.

-- 2.3.4   Return to the home screen.
--         Click the Snowflake logo in the upper left corner.

-- 2.4.0   Create a Dashboard
--         We will now create a dashboard which displays results and charts for
--         the same query that we were using earlier in this lab. Please follow
--         the instructions in the PDF workbook.

-- 2.4.1   Go to the Dashboards page.
--         In the left navigation bar, hover over Projects, then select
--         Dashboards.

-- 2.4.2   Create a new dashboard named OTTER Gross Sales.
--         Click the blue +Dashboard button.
--         In the pop-up box that appears, enter your user name followed by
--         Gross Sales as the dashboard name, and click Create Dashboard.
--         You will see an empty dashboard with no tiles.
--         You may see a warning banner relating to secondary roles and
--         dashboards. You can ignore this by clicking on the X in the banner.

-- 2.4.3   Set the role and virtual warehouse for the dashboard.
--         At the top right of the empty dashboard, set your role and the
--         virtual warehouse. The role should be set to FUND_ROLE, the warehouse
--         will probably be set to No warehouse selected.
--         Click the button and set your role to FUND_ROLE and your virtual
--         warehouse to OTTER_FUND_WH.

-- 2.5.0   Add Tiles to the Dashboard
--         There are several ways to add a tile to a dashboard, you can:
--         Create a new tile from scratch.
--         Edit the query for a tile that contains numeric data and convert it
--         to a chart tile.
--         Duplicate an existing tile to modify its query.
--         We are going to use all three methods.
--         Tiles are used to present data or charts in a dashboard.

-- 2.5.1   Create a new tile and import SQL.
--         Click the blue New Tile button, then select From SQL Worksheet.
--         An empty SQL worksheet opens. The name defaults to a timestamp.
--         Change the name to Gross Sales Data. Click the drop-down beside the
--         name of the sheet, type in the new name Gross Sales Data, then press
--         the ENTER (or RETURN) key.
--         Click the drop-down beside the name of the sheet again, then select
--         Import SQL from File.
--         - Navigate to where you downloaded and unzipped the lab files.
--         - Open the USERS folder, and then open the sub-folder with your
--         username.
--         - Select and import the file for this lab: ##-visualizations-in-
--         snowsight.sql.

-- 2.5.2   Set the database and schema context for the dashboard tile.
--         To set the context, use the drop-down menu at the top left of the SQL
--         pane, it will probably show No Database selected.
--         Select SNOWBEARAIR_DB as the database and PROMO_CATALOG_SALES as the
--         schema. Click outside the database/schema selection box to close it.

-- 2.5.3   Run the query to determine monthly revenue grouped by order priority.
--         Scroll down to this section and run the query to determine the
--         monthly revenue grouped by order priority.

SELECT 
  -- Truncate order date to month level for aggregation
  DATE_TRUNC('MONTH', o.o_orderdate) AS month,
  -- Calculate total revenue for the month
  SUM(l.l_extendedprice) AS sum_gross_revenue,
  -- Group by order priority level
  o.o_orderpriority AS order_priority,
  -- Count distinct orders to avoid duplicates from line items
  COUNT(DISTINCT o.o_orderkey) AS order_count
FROM
        snowbearair_db.promo_catalog_sales.customer c
        INNER JOIN snowbearair_db.promo_catalog_sales.orders o on c.c_custkey = o.o_custkey
        INNER JOIN snowbearair_db.promo_catalog_sales.lineitem l on o.o_orderkey = l.l_orderkey
GROUP BY month, o_orderpriority
ORDER BY month, o_orderpriority;


-- 2.5.4   Click - Return to OTTER Gross Sales in the upper left corner.
--         You should now see one tile named Gross Sales Data that shows the
--         tabular result.

-- 2.5.5   Add a chart tile from the existing tile.
--         In your dashboard, click the ellipsis (…) in the upper right corner
--         or your existing tile and select Edit Query. You will be taken back
--         to the original query with the query result.
--         Click the Chart button just below the SQL pane and just above the
--         query results.
--         Modify the chart with the following settings:
--         Chart type: Bar
--         Data
--         Y-Axis - SUM_GROSS_REVENUE aggregated by sum
--         X-Axis - MONTH bucketed by year
--         Use the ESC key to close the Column editor.
--         Appearance
--         Orientation - Vertical
--         Order bars by MONTH
--         Order direction Ascending
--         Series direction Ascending
--         Label the axes appropriately.
--         The resulting chart should look similar to the one shown below.

-- 2.5.6   Click - Return to OTTER Gross Sales in the upper left.
--         You should now see a dashboard with two tiles like the one shown
--         below:

-- 2.5.7   Add another chart tile by duplicating an existing chart tile.
--         In your dashboard, click the ellipsis (…) in the upper right corner
--         of the bar chart tile and select Duplicate Tile.
--         You should see a new chart tile named Copy of Gross Sales Data.

-- 2.5.8   Rename the copied tile and convert the chart to a stacked bar chart.
--         In your dashboard, click the ellipsis (…) in the upper right corner
--         of your copied tile and select View Chart. You will be taken back to
--         the query with the chart.
--         Change the name to Gross Sales Data - Stacked Bar Chart. Click the
--         drop-down beside the name of the sheet, type in the new name Gross
--         Sales Data - Stacked Bar Chart, then press the ENTER (or RETURN) key.
--         Modify the chart to a stacked bar chart using ORDER_PRIORITY for
--         grouping, with the following settings:
--         Chart type: Bar
--         Data
--         Y-Axis - SUM_GROSS_REVENUE aggregated by sum
--         X-Axis - MONTH bucketed by year
--         Click + Add Column, select ORDER_PRIORITY, and use as Series
--         Use the ESC key to close the Column editor.
--         Appearance
--         Orientation - Vertical
--         Grouping - Stacked
--         Stretching - No stretching
--         Order bars by MONTH
--         Order direction Ascending
--         Series direction Ascending
--         Label the axes appropriately.
--         The resulting chart should look similar to the one shown below.

-- 2.5.9   Click - Return to OTTER Gross Sales in the upper left.
--         You should now see a dashboard with three tiles like the one shown
--         below:

-- 2.6.0   Share Your Dashboard

-- 2.6.1   Click the Share button in the upper-right corner.
--         In this dialog box, you can search for someone and invite them to
--         view and use this dashboard.

-- 2.6.2   Enter Instructor1 as the user to share with.

-- 2.6.3   Set permissions to View results.
--         Click the down arrow to the right of the user name, and select View
--         results. Then click Done. You have now shared your dashboard.

-- 2.6.4   Return to the home screen.
--         Click the Snowflake logo in the upper left corner.

-- 2.7.0   Key Takeaways
--         - While conducting ad hoc analyses, you can use filters to gain
--         insights into your data.
--         - You can visualize data in workspaces and dashboards.
--         - Snowflake makes it easy to share dashboards with colleagues.
