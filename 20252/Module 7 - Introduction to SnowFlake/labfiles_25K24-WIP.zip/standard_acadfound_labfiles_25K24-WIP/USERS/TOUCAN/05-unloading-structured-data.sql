
-- 5.0.0   Unloading Structured Data
--         The purpose of this lab is to introduce you to data unloading.
--         - Unload table data into a Table Stage in pipe-delimited file format.
--         - Write a SQL statement containing a JOIN to unload a table into an
--         internal stage.
--         HOW TO COMPLETE THIS LAB
--         Since the workbook PDF has useful diagrams and illustrations (not
--         present in the .SQL files), we recommend that you read the
--         instructions from the workbook PDF. In order to execute the code
--         presented in each step, use the SQL code file provided for this lab.
--         Let’s get started!

-- 5.1.0   Upload and Open the SQL File

-- 5.1.1   Go to the Workspaces page.
--         In the left navigation bar, hover over Projects, then select
--         Workspaces.

-- 5.1.2   Close all open tabs.
--         Click the gear icon in the top right of the Workspaces page and
--         select Close all tabs.

-- 5.1.3   Upload the SQL file for this lab into My Workspace.
--         In the My Workspace pane, click + Add new, then select Upload Files.
--         Then:
--         - Navigate to where you downloaded and unzipped the lab files.
--         - Open the USERS folder, and then open the sub-folder with your
--         username.
--         - Select and upload the SQL file for this lab.
--         Once the file has been uploaded, select the file in the My Workspace
--         pane. The file opens in a new Workspaces tab.

-- 5.2.0   Unload Table Data into a Table Stage in Pipe-delimited File Format

-- 5.2.1   Set your context.

USE ROLE fund_role;

CREATE WAREHOUSE IF NOT EXISTS TOUCAN_fund_wh;
USE WAREHOUSE TOUCAN_fund_wh;

CREATE DATABASE IF NOT EXISTS TOUCAN_fund_db;

USE SCHEMA TOUCAN_fund_db.public;


-- 5.2.2   Create a fresh version of the REGION table with five records to
--         unload.

CREATE or REPLACE table region AS 
   SELECT * FROM snowflake_sample_data.tpch_sf1.region;

-- Run the query below to view the contents of the table

SELECT * FROM region;


-- 5.2.3   Create a file format called mypipeformat.

CREATE OR REPLACE FILE FORMAT mypipeformat
  TYPE = CSV
  COMPRESSION = NONE
  FIELD_DELIMITER = '|'
  FILE_EXTENSION = 'tbl';


-- 5.2.4   Unload the data to the REGION table stage.
--         Remember that a table stage is automatically created for each table.
--         Use the slides, workbook, or Snowflake documentation for questions on
--         the syntax. You will use MYPIPEFORMAT for the unloading. This will
--         cause the unloaded file to be formatted according to the
--         specifications of the MYPIPEFORMAT file format. The file format
--         specified COMPRESSION = NONE. So, the files that are created during
--         the unloading process will not be compressed.

COPY INTO @%region
FROM region
FILE_FORMAT = (FORMAT_NAME = mypipeformat);


-- 5.2.5   List the stage and query the file to verify that the data is there.

LIST @%region;

SELECT * 
FROM @%region/data_0_0_0.tbl
( FILE_FORMAT => 'mypipeformat');


-- 5.2.6   Remove the file from the region table’s stage and verify it is gone.

REMOVE @%region;

LIST @%region;


-- 5.3.0   Use a SQL statement Containing a JOIN to Unload Data into an Internal
--         Stage
--         This activity is essentially the same as the previous activity. The
--         difference is that you will unload data from more than one table into
--         a single file.

-- 5.3.1   Do a SELECT with a JOIN on the region and nation tables.
--         Review the output from your JOIN.

SELECT * 
FROM snowflake_sample_data.tpch_sf1.region r 
JOIN snowflake_sample_data.tpch_sf1.nation n ON r.r_regionkey = n.n_regionkey;


-- 5.3.2   Create a named stage (you can give any name to a named stage).

CREATE OR REPLACE STAGE mystage;


-- 5.3.3   Unload the joined data into the stage you created.

COPY INTO @mystage FROM
(SELECT * 
  FROM snowflake_sample_data.tpch_sf1.region r 
  JOIN snowflake_sample_data.tpch_sf1.nation n
  ON r.r_regionkey = n.n_regionkey)
FILE_FORMAT = (FORMAT_NAME = mypipeformat);


-- 5.3.4   Verify the file is in the stage.

LIST @mystage;

SELECT $1, $2, $3, $4, $5, $6, $7 
FROM @mystage/data_0_0_0.tbl (FILE_FORMAT => mypipeformat);


-- 5.3.5   Remove the file from the stage and verify removal.

REMOVE @mystage;

LIST @mystage;


-- 5.3.6   Remove the stage.

DROP STAGE mystage;


-- 5.3.7   Resize and suspend the virtual warehouse.

ALTER WAREHOUSE TOUCAN_fund_wh SET WAREHOUSE_SIZE=XSmall;

ALTER WAREHOUSE TOUCAN_fund_wh SUSPEND;


-- 5.4.0   Key Takeaways
--         - The COPY INTO command can be used to unload data.
--         - Data from multiple tables can be unloaded using a JOIN statement.
--         - You can use the LIST command to see what files are in a stage.
