
-- 1.0.0   Introduction to Snowflake and Snowflake Objects
--         The purpose of this lab is to familiarize you with Snowflake’s
--         Snowsight user interface. Specifically, you will learn how to use
--         Snowsight Workspaces to upload a SQL file, create Snowflake objects,
--         and run queries.
--         - Log in and set up MFA.
--         - Familiarize yourself with the Snowsight user interface.
--         - Explore Workspaces.
--         - Upload a SQL file.
--         - Set the context.
--         - Create virtual warehouses, databases, schemas, and tables.
--         - Run simple queries.
--         - Set your user defaults and profile.
--         You are working for Snowbear Air, which is an airline that flies to
--         fun destinations all over the world. You’ve been asked to create a
--         few Snowflake objects in a development environment to test out your
--         SQL statements. You will need to:
--         - Create a virtual warehouse
--         - Create a database and a schema
--         - Create a table and populate it with data
--         - Run some test queries
--         Before getting started, make sure you have downloaded the lab files
--         for this course to a convenient location and unzipped the archive.
--         When you do this, you will see a folder named USERS. This folder
--         contains sub-folders with usernames - locate your username and open
--         that folder. These are the SQL files you will use throughout this
--         course.
--         HOW TO COMPLETE THIS LAB
--         Since the workbook PDF has useful diagrams and illustrations (not
--         present in the .SQL files), we recommend that you read the
--         instructions from the workbook PDF. In order to execute the code
--         presented in each step, use the SQL code file provided for this lab.
--         For this lab in particular, you MUST use the workbook for the first
--         part, as you will be doing things outside of the Workspaces area (and
--         thus, the SQL file will not be visible).
--         Let’s get started!

-- 1.1.0   Log In and Set Up MFA
--         Snowflake is secure by default. MFA is enforced for all Snowsight
--         users. The instructions below explain how to log in to Snowsight and
--         set up MFA.
--         Your instructor will have already walked you through this process.

-- 1.1.1   Access the URL provided to you for this course.
--         You will be taken to a login screen for the lab account.

-- 1.1.2   Enter your username and temporary password.
--         Obtain these credentials from your instructor.

-- 1.1.3   Set up MFA using the Passkey method.
--         You will be prompted to Set up MFA.
--         Click on the Passkey option.
--         Follow the options available on your local machine to save the
--         passkey. We recommend saving the passkey locally using either a
--         browser-based password manager, or using Windows Hello (on a Windows
--         machine). Most options will require verification of your identity
--         using biometrics or a PIN.
--         Once the passkey has been successfully added, give it a nickname and
--         then click Continue.
--         If the passkey method does not work in your environment, you can
--         choose to set up MFA using the authenticator method.

-- 1.1.4   Change your password when prompted.
--         This is not an error - the lab environments are set up so all users
--         are asked to change their password the first time they log in.

-- 1.2.0   Explore the Home Screen
--         When you first log in, you will be placed into the Home screen.
--         You may see a What’s new pop-up tour of the changes to the Snowsight
--         navigation menu. Click though the What’s new tour to see the changes.
--         The home screen will look similar to the screen below:

-- 1.2.1   Locate the user menu.
--         This is located in the lower left corner. Here, you will find your
--         username and the role that you currently have set. You will learn
--         more about roles later on. Your Snowflake account information is also
--         available from the user menu. Click the user menu to see the options.

-- 1.2.2   Locate the left navigation bar.
--         This is located along the left side, above the user menu. You can use
--         the navigation bar to move through various areas of the user
--         interface. You can hide (collapse) or show (expand) the navigation
--         bar by clicking on the highlighted icon.

-- 1.2.3   Locate the active panel.
--         This is the large area on the right. This will change based on which
--         menu option you have activated from the navigation bar. Select
--         various options in the navigation bar and observe the changes to the
--         active panel.
--         Clicking the Snowflake logo in the upper left corner, or clicking the
--         Home icon will bring you back to the home screen.

-- 1.3.0   Review Your User Settings

-- 1.3.1   Access the Settings page.
--         Click the user menu in the lower left corner, then select Settings.

-- 1.3.2   Review your profile.
--         The settings page defaults to My Profile. Observe that you are unable
--         to change your name or email address. This is because your user role
--         does not have the privileges to make those changes.
--         You will set your name and email address by running a stored
--         procedure in a subsequent step.

-- 1.3.3   Review the Authentication settings.
--         On the settings page, select Authentication.
--         You can change your password and manage your MFA settings. Confirm
--         that you see the MFA method that you set up. You should see only one
--         registered MFA method similar to the example shown below.
--         Multiple MFA methods can be set up for flexibility. It may be
--         beneficial to set up one passkey method and one authenticator app
--         (TOTP - Time-based One-Time Passcode) method. When more than one
--         method has been set up, one of the configured methods can be set as
--         the default.

-- 1.3.4   Explore the other user settings.
--         Preferences - You can set preferences like the theme, language,
--         default role, and default warehouse. Do not worry about the default
--         role and warehouse right now. You will work with these shortly.
--         Notifications - You can toggle whether or not to receive a
--         notification when a query finishes running in the background.

-- 1.3.5   Optionally, set the Snowsight UI appearance to Dark mode.
--         Click the user menu in the lower left corner, then select Appearance
--         > Dark. Switch back to the System mode if you don’t like the Dark
--         mode.

-- 1.3.6   Return to the home screen.
--         Click the Snowflake logo in the upper left corner.

-- 1.4.0   Explore Universal Search
--         Universal Search lets you easily find objects in your account, data
--         products in the Snowflake marketplace, relevant Snowflake
--         documentation, and knowledge base articles. You can use natural
--         language to describe what you are looking for.
--         You can access Universal Search from the Snowsight home page or by
--         using the Search option in the navigation bar.

-- 1.4.1   Go to the Search page.
--         Click the Search icon in the navigation bar.

-- 1.4.2   Search for information on virtual warehouses.
--         In the search field, type in: What are virtual warehouses? Then press
--         the enter or return key to execute the search.
--         Observe that Universal Search returns information in various
--         categories like Documentation, Tables and views, Marketplace, etc.
--         Optionally, click on one of the documentation links. The relevant
--         document opens in a new browser tab. View the documentation and then
--         return to the Snowsight UI.

-- 1.4.3   Search for documentation on Snowflake supported SQL commands.
--         In the search field, type in: Show me documentation on supported SQL
--         commands. Then press the enter or return key to execute the search.
--         In the search results, you should see the SQL command reference.
--         Click the link, the command reference opens in a new browser tab.
--         The SQL command reference is a valuable resource. From here, you can
--         view all the SQL commands supported by Snowflake. The All commands
--         entry provides an alphabetical list where you can find specific
--         commands and click on them to be taken to the documentation page for
--         that command.
--         Browse the command reference and then return to the Snowsight UI.

-- 1.5.0   Explore Workspaces
--         Workspaces is a new Snowsight feature introduced in September 2025.
--         It provides a unified editor for creating, organizing, and managing
--         code across multiple file types. You can use Workspaces to analyze
--         data and develop models. Workspaces are private to the user and
--         support integration with Git for version control, collaboration, and
--         alignment with existing workflows.
--         In this course, most of the work will be done using SQL files in
--         Workspaces.

-- 1.5.1   Go to the Workspaces page.
--         In the left navigation bar, hover over Projects, then select
--         Workspaces.

-- 1.5.2   Take the Workspaces tour.
--         The Workspaces basics tour may launch automatically the first time
--         you go to the Workspaces page.
--         To launch the tour manually, in the Workspaces Home tab, click Launch
--         tour.
--         Click through the tour.

-- 1.5.3   Get familiar with the Workspaces interface.
--         You should see the Workspaces Home tab and other panes as seen in the
--         graphic below.
--         Workspaces: Each user has a default workspace called My Workspace
--         that cannot be renamed or deleted. You can create new private
--         workspaces or Git-backed workspaces. You can create files, folders,
--         and nested subfolders in each workspace and drag files between
--         folders. You can also upload files or folders from your local
--         machine.
--         Worksheets: You can open and edit worksheets you own or have
--         permissions on. You can convert a worksheet into a file in a
--         workspace. In this lab environment, Workspaces is the default SQL
--         editor, so you may not see the Worksheets pane.
--         Database Explorer: Shows a hierarchical view of all databases your
--         role has access to, the schemas for each database, and other objects,
--         organized by type. You can use the filter to search for objects.
--         Home tab: Shows keyboard shortcuts and also has the Launch tour
--         button.
--         Query History: You can view the query history of all the queries you
--         have run for the current file or all files in the workspace.
--         You can also hide the side panes and the query history panes.

-- 1.6.0   Upload a SQL File and Set Your Context

-- 1.6.1   Upload the SQL file for this lab.
--         In the My Workspace pane, click + Add new, then select Upload Files.
--         - Navigate to where you downloaded and unzipped the lab files.
--         - Open the USERS folder, and then open the sub-folder with your
--         username.
--         - Select and upload the file for this lab: 01-introduction-to-
--         snowflake-and-snowflake-objects.sql. The SQL file is added to the My
--         Workspace pane.
--         - Select the file in the My Workspace pane, the file opens in a new
--         Workspaces tab.
--         Workspaces allow you to upload an entire folder of files. This lab
--         workbook provides instructions on uploading one lab SQL file at a
--         time. You may choose either method.

-- 1.6.2   Familiarize yourself with the components of an open SQL file.
--         Each open SQL file in Workspaces is a session connected to Snowflake.
--         You can have many active open SQL files (or sessions) at once. Each
--         SQL file has a context, which defines the default components you are
--         working with during this session.
--         Your context is an important concept to understand. It defines the
--         objects that are being used by default in this session. It consists
--         of a database, a schema, a role, and a virtual warehouse.
--         - The role that is active will impact what objects you can see and
--         what you can do with them.
--         - The warehouse defines what virtual warehouse you will use to run
--         commands.
--         - The database and schema define the default location you are acting
--         in. For example, if you run SELECT * FROM mytable, Snowflake will
--         look for mytable in the database and schema currently set in your
--         context. If you want to select from a table outside your current
--         context, you must provide the full path to that object, for example,
--         SELECT * FROM my_database.my_schema.mytable.
--         Spend a few minutes to orient yourself to the open SQL file before
--         beginning.
--         Locate the following components:
--         At the top left of the open file tab is a blue button with a white
--         arrow in it. This is the run button used to run your SQL commands. To
--         the right of the run button is a down arrow. The down arrow lets you
--         Run All statements in your SQL file. You can ignore that for now.
--         In the upper middle, you will see a place where your role and virtual
--         warehouse for this session are set. This sets one part of your
--         context. You should see FUND_ROLE set for your role and Choose
--         warehouse where the virtual warehouse name will be. You will create
--         and set a virtual warehouse later in this exercise.
--         To the right of your role and virtual warehouse, you set your default
--         database and schema for this session. You will probably see Choose
--         database at this point, but once you set your context, you will see
--         the database and schema names.
--         At the upper right corner you will see the Settings (gear) icon. You
--         can use this to close all open tabs or split panes.
--         The large area is the SQL editor pane. This is where you will run SQL
--         commands.

-- 1.6.3   Set your context.
--         If your current role is not set to FUND_ROLE, click on the role that
--         is currently set, and then select FUND_ROLE. Click outside the box to
--         close it.
--         Click Choose database. A list of available databases appears.
--         Select SNOWBEARAIR_DB as your database and MODELED as your schema.
--         Click outside the box to close it.

-- 1.6.4   Create a virtual warehouse and set it in your context.
--         Before you can run any SQL commands, you need a virtual warehouse.
--         Use the following SQL to create a virtual warehouse and to set it in
--         your context.
--         All the SQL you need to run in this course is inside the .SQL files
--         provided. Scroll down in the SQL file until you find this step in the
--         file. Position your cursor in the command you want to run and either
--         click the run button (the blue button with the white arrow in it) or,
--         even better, use the keyboard shortcut (CTRL+RETURN for Windows or
--         CMD+RETURN for Mac). This is how you will run SQL commands for the
--         rest of the course. Do not copy and paste from the PDF workbook, as
--         you may get unexpected results.

USE ROLE fund_role;

CREATE OR REPLACE WAREHOUSE LOBSTER_fund_wh WITH
  WAREHOUSE_SIZE = XSmall 
  INITIALLY_SUSPENDED = true;

USE WAREHOUSE LOBSTER_fund_wh;

--         The results of any query are displayed in the Results tab below.
--         If you look in the role/warehouse part of your context, you will now
--         see FUND_ROLE as your role and LOBSTER_FUND_WH as your virtual
--         warehouse.

-- 1.6.5   View the list of databases in the Database Explorer pane.
--         In the Database Explorer pane (bottom left) make sure that Objects is
--         selected.
--         Observe the list of databases that this role has access to.

-- 1.6.6   Change your role to PUBLIC.
--         You can do this with SQL or by clicking in the context menu selecting
--         it there.
--         To change your role with SQL, run this:

USE ROLE public;

--         Look at the list of databases in the Database Explorer pane. You
--         should now see a shorter list of databases that you have access to.
--         This is an illustration of how your role impacts what you can see and
--         what you can do.
--         When you change your role to PUBLIC, your context may change because
--         the PUBLIC role has access to a limited set of objects.

-- 1.6.7   Change your role back to FUND_ROLE and reset your context.
--         To change your role with SQL, run this:

USE ROLE fund_role;

--         The list of databases should be re-populated with the full list seen
--         before.
--         Set your virtual warehouse and schema.

USE WAREHOUSE LOBSTER_fund_wh;
USE SCHEMA snowbearair_db.modeled;


-- 1.7.0   Run a Few Queries and Modify a Query with Copilot Inline

-- 1.7.1   Show the tables that are in your current context.

SHOW TABLES;

--         The SHOW command is a metadata operation and does not require a
--         virtual warehouse.

-- 1.7.2   Query some tables.
--         During this course, many of our exercises will use data from the
--         SNOWBEARAIR_DB database. Take a look at some of that data using the
--         two queries below.

SELECT *
FROM members
LIMIT 10;

SELECT TOP 5
    c.c_lastname,
    c.c_firstname,
    c.c_acctbal
FROM snowbearair_db.promo_catalog_sales.customer c
ORDER BY c.c_acctbal DESC;

--         In the second query above, notice that we supplied the full path
--         (database.schema.table) in the FROM clause. This is because our
--         current context is set to snowbearair_db.modeled, and the table we
--         queried is in a different schema.
--         Run another command.

SELECT 
  c_firstname,
  c_lastname,
  o_orderkey,
  o_totalprice
FROM
  promo_catalog_sales.orders
JOIN
  promo_catalog_sales.customer
ON
  o_custkey = c_custkey
ORDER BY o_totalprice DESC
LIMIT 10;

--         In this command, we only provided the schema name
--         (promo_catalog_sales) and the object name (orders) in the FROM
--         clause. This is because our context already has the correct database
--         (snowbearair_db). You can specify the full path, but if the database
--         is correct, you only need to specify the schema.

-- 1.7.3   Use Copilot inline to modify the previous query to show top 100
--         customers in America.
--         Make sure your cursor is in the previous query and open Copilot
--         inline. Use the CMD+I (MacOS) or CTRL+I (Windows) keyboard shortcut.
--         Type in the suggested prompt and send it to Copilot: Modify the query
--         to show the top 100 customers in America, based on revenue. Include
--         the full name in one column, and order date. Also add comments to
--         explain the logic used for the query.
--         Review the suggested query. Click Accept and then run the query.

-- 1.8.0   Create Objects
--         One of the things you may do during your work is create objects, such
--         as databases, schemas, and tables. Let’s create a few objects that
--         you will use during this course.

-- 1.8.1   Create a database called LOBSTER_fund_db.

CREATE OR REPLACE DATABASE LOBSTER_fund_db;


-- 1.8.2   Create a schema called my_schema in the database you just created.

CREATE OR REPLACE SCHEMA LOBSTER_fund_db.my_schema;

USE SCHEMA LOBSTER_fund_db.my_schema;


-- 1.8.3   Create a table.

CREATE OR REPLACE TABLE my_favorite_actors (name VARCHAR);

--         Now, insert a few rows into your table, replacing the placeholder
--         names with the names of your favorite actors.

INSERT INTO my_favorite_actors
VALUES
  ('Heath Ledger'),
  ('Michelle Pfeiffer'),
  ('Meryl Streep'),
  ('Anthony Hopkins'),
  ('Bruce Lee');

--         Check the values in your table.

SELECT * FROM my_favorite_actors;


-- 1.8.4   Suspend (shut down) your virtual warehouse.

ALTER WAREHOUSE LOBSTER_fund_wh SUSPEND;

--         The virtual warehouses in the lab environment are configured to shut
--         down after 10 minutes of inactivity. In your work environment, your
--         role may not have the privileges to shut down virtual warehouses.

-- 1.9.0   Set Your User Defaults
--         If you are usually working with objects in the same database and
--         schema and using the same role and virtual warehouse, it is helpful
--         to define your default context. When you open a new session to
--         Snowflake these values will already be set for you.

-- 1.9.1   Run this command to set your defaults:

ALTER USER LOBSTER SET
   DEFAULT_ROLE = fund_role
   DEFAULT_WAREHOUSE = LOBSTER_fund_wh
   DEFAULT_NAMESPACE = LOBSTER_fund_db.my_schema;


-- 1.10.0  Update Your User Profile
--         In the next steps, you will run a stored procedure to update your
--         user profile. This is necessary because elevated privileges are
--         required to perform this action.

-- 1.10.1  Create variables for your first name, last name and email address.

-- Edit each of the following three lines to add your first name, lastname, and email address.
-- Run the commands to set the variables.
SET myfirstname = 'fname';
SET mylastname = 'lname';
SET myemail = 'fname.lname@company.com';

-- Confirm that the variables are set.
SELECT $myfirstname, $mylastname, $myemail;


-- 1.10.2  Call the stored procedure to update your user profile.
--         You call a stored procedure which runs with elevated privileges that
--         allow you to make the necessary changes.

-- Call the stored procedure to update your user profile
CALL training_db.common.update_profile(current_user(), $myfirstname, $mylastname, $myemail);

-- Confirm that settings have taken effect
DESCRIBE USER LOBSTER;


-- 1.10.3  Confirm the profile changes via the user menu.
--         Click the user menu in the lower left corner, then select Settings.
--         You may have to refresh your browser if you do not see the changes.
--         Click Resend verification. You should get a verification email to the
--         address that you specified.

-- 1.11.0  OPTIONAL - Create a New SQL File in Workspaces

-- 1.11.1  Create a new SQL file from scratch in My Workspace.
--         In the My Workspace pane, click + Add new, then select SQL File.
--         Name the file fundtest and press Enter.
--         The new empty fundtest.sql file opens in a new Workspaces tab.
--         Observe that this file has the default context that you set in an
--         earlier step in this lab.

-- 1.11.2  Split the pane so that you can see the new SQL file and previous SQL
--         file side-by-side.
--         Click the gear icon in the top right of the Workspaces page and
--         select Split pane.
--         You should see the previously opened SQL file and the new SQL file
--         side-by-side.

-- 1.11.3  Run a few queries in the new SQL file.
--         Try running a few queries in the new SQL file.

-- 1.12.0  Key Takeaways
--         - You are ready to use Snowsight for your day-to-day Snowflake
--         operations.
--         - You can create database objects using the Snowsight UI and by
--         executing SQL code in a SQL file. We did this exercise using SQL
--         code.
--         - You can browse database objects and view their details by using the
--         Database Explorer in Workspaces.
--         - The context of a session consists of a role, virtual warehouse,
--         database, and schema.
--         - The context can be set via the Snowsight UI or SQL statements.
--         - Workspaces is a unified editor for creating, organizing, and
--         managing code across multiple file types.
