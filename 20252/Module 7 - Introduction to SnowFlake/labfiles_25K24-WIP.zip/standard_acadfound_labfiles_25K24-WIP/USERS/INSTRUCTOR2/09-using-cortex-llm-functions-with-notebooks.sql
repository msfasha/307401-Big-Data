
-- 9.0.0   Using Cortex LLM Functions with Notebooks
--         The purpose of this lab is to familiarize you with the Snowflake
--         Cortex LLM functions and allow you to practice using some of the
--         specialized LLM functions using a Snowflake Notebook.
--         You will use SQL commands to create an internal stage, copy an
--         existing notebook to your stage, and then create a new notebook.
--         You will then use the notebook you created to explore the Cortex LLM
--         functions.
--         - Create a new notebook by copying a notebook file from an existing
--         stage.
--         - Use the SENTIMENT LLM function.
--         - Use the EXTRACT_ANSWER LLM function.
--         - Use the TRANSLATE LLM function.
--         - Use the SUMMARIZE LLM function.
--         HOW TO COMPLETE THIS LAB
--         Since the workbook PDF has useful diagrams and illustrations (not
--         present in the .SQL files), we recommend that you read the
--         instructions from the workbook PDF. In order to execute the code
--         presented in each step, use the SQL code file provided for this lab.
--         Let’s get started!

-- 9.1.0   Upload and Open the SQL File

-- 9.1.1   Go to the Workspaces page.
--         In the left navigation bar, hover over Projects, then select
--         Workspaces.

-- 9.1.2   Close all open tabs.
--         Click the gear icon in the top right of the Workspaces page and
--         select Close all tabs.

-- 9.1.3   Upload the SQL file for this lab into My Workspace.
--         In the My Workspace pane, click + Add new, then select Upload Files.
--         Then:
--         - Navigate to where you downloaded and unzipped the lab files.
--         - Open the USERS folder, and then open the sub-folder with your
--         username.
--         - Select and upload the SQL file for this lab.
--         Once the file has been uploaded, select the file in the My Workspace
--         pane. The file opens in a new Workspaces tab.

-- 9.2.0   Create Lab Objects and Set Your Context

-- 9.2.1   Set your context.

USE ROLE fund_role;

CREATE WAREHOUSE IF NOT EXISTS INSTRUCTOR2_fund_wh;
USE WAREHOUSE INSTRUCTOR2_fund_wh;

CREATE DATABASE IF NOT EXISTS INSTRUCTOR2_fund_db;

CREATE SCHEMA IF NOT EXISTS INSTRUCTOR2_fund_db.llm;
USE SCHEMA INSTRUCTOR2_fund_db.llm;


-- 9.2.2   Create an internal stage.
--         We will create a stage to store the notebook file.

CREATE OR REPLACE STAGE 
   INSTRUCTOR2_fund_db.llm.notebook_files
   ENCRYPTION = (TYPE = 'SNOWFLAKE_SSE')
   DIRECTORY = (ENABLE = true);


-- 9.3.0   Copy Existing Notebook to Your Internal Stage

-- 9.3.1   List the files on the resources stage.

LIST @training_db.resources.notebook_files/fund/cortex_llm_lab/;

--         You should see a file called
--         using_cortex_llm_functions_notebook.ipynb.

-- 9.3.2   Copy notebook to the internal stage.

COPY FILES INTO @INSTRUCTOR2_fund_db.llm.notebook_files/fund/cortex_llm_lab/
FROM @training_db.resources.notebook_files/fund/cortex_llm_lab/using_cortex_llm_functions_notebook.ipynb;


-- 9.3.3   Confirm that the notebook has been copied to the internal stage.

LIST @INSTRUCTOR2_fund_db.llm.notebook_files/fund/cortex_llm_lab/;

--         You should see a file called
--         using_cortex_llm_functions_notebook.ipynb.

-- 9.4.0   Create a New Notebook

-- 9.4.1   Create a new notebook using the notebook that you copied.

CREATE OR REPLACE NOTEBOOK INSTRUCTOR2_Using_Cortex_LLM_Functions_Notebook
FROM '@INSTRUCTOR2_fund_db.llm.notebook_files/fund/cortex_llm_lab/'
MAIN_FILE = 'using_cortex_llm_functions_notebook.ipynb'
QUERY_WAREHOUSE = INSTRUCTOR2_fund_wh;


-- 9.4.2   Confirm that your notebook has been created.

SHOW NOTEBOOKS;

--         You will see when your notebook was created, its name, the names of
--         the database and schema where it is, the name of the notebook owner,
--         the query virtual warehouse for the notebook, and the owner’s role
--         type.

-- 9.5.0   Complete This Lab Using the Notebook

-- 9.5.1   Open the the notebook you just created.
--         In the left navigation bar, hover over Projects, then select
--         Notebooks.
--         You should see the notebook you just created,
--         INSTRUCTOR2_Using_Cortex_LLM_Functions_Notebook.
--         Once you select your new notebook, it will open and load, which may
--         take several seconds. You are ready to go when you see the initial
--         markdown cell fully populated with the introductory information!

-- 9.5.2   Work through the notebook to complete this lab.
--         To complete the remainder of this exercise, work through the notebook
--         cells from top to bottom. Read the markdown cells and run the SQL
--         cells as directed.
